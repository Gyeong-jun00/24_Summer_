#pragma once
#include <Windows.h>
#include <iostream>

#include <vector>
using std::vector;

#include <string>
using std::string;
using std::wstring;

#include "define.h"
#include "struct.h"